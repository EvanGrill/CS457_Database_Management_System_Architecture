
import unittest 

import config 

from Parser import Parser

class TestParser(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pass 

    @classmethod
    def tearDownClass(cls):
        pass 

    def setUp(self):
        pass 

    def tearDown(self):
        pass 



if __name__ == '__main__':
    unittest.main()
