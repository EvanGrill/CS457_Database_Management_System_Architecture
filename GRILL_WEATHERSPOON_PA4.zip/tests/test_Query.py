
import unittest 

import config 

from Query import Query

class TestQuery(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pass 

    @classmethod
    def tearDownClass(cls):
        pass 

    def setUp(self):
        pass 

    def tearDown(self):
        pass 



if __name__ == '__main__':
    unittest.main()
