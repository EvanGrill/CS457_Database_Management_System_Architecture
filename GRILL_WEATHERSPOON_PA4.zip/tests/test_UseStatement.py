
import unittest 

import config 

from UseStatement import UseStatement

class TestUseStatement(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pass 

    @classmethod
    def tearDownClass(cls):
        pass 

    def setUp(self):
        pass 

    def tearDown(self):
        pass 


    def test_execute(self):
        pass


if __name__ == '__main__':
    unittest.main()
